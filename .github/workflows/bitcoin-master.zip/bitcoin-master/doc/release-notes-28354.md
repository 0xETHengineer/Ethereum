Tests
-----

- Non-standard transactions are now disabled by default on testnet
  for relay and mempool acceptance. The previous behaviour can be
  re-enabled by setting `-acceptnonstdtxn=1`. (#28354)
