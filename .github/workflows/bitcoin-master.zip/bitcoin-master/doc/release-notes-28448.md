RPC
---

- Setting `-rpcserialversion=0` is deprecated and will be removed in
  a future release. It can currently still be used by also adding
  the `-deprecatedrpc=serialversion` option. (#28448)
